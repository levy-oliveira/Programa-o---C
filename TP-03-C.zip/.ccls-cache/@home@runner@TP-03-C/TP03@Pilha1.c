#include "Pilha.h"
#include <stdio.h>
#include <stdlib.h>

struct node {
  Aluno *aluno;
  struct node *proximo;
};

typedef struct node No;

#define CAPACIDADE_INICIAL 10

struct pilha {
  No *primeiro;
};

/* Aloca espaço em memória e retorna uma pilha */
Pilha *pilha_cria() {
  Pilha *pilha = (pilha *)malloc(sizeof(pilha));
  pilha->primeiro = NULL;
  return pilha;
  
}

/* Libera a memória de uma pilha previamente criada e atribui NULL ao ponteiro
 * pilha. Retorna 1 caso seja possível fazer a liberação e 0 caso a pilha
 * informada seja NULL. */
int pilha_libera(Pilha **pilha) {
  if (pilha != NULL) {
    if ((*pilha)->primeiro != NULL) {
      No *aux = (*pilha)->primeiro;
      do {
        alu_libera(&aux->aluno);
        aux = aux->proximo;
      } while (aux != NULL);
    }
    free(*pilha);
    *pilha = NULL;
    return 1;
  }
  return 0;
}

/* Insere um aluno na pilha. Retorna 1 se foi possível adicionar, 0 caso já
 * exista um aluno com a mesma matricula (nesse caso, o aluno não pode ser
 * adicionado) e -1 caso a pilha ou aluno sejam NULL
 */
int pilha_insere(Pilha *pilha, Aluno *aluno) {
  if(pilha == NULL || aluno == NULL){
    return -1;
  }
  int matricula_base;
  int matricula;
  char nome[50];
  char curso[30];
  alu_acessa(aluno, &matricula_base, nome, curso);
  
  if (pilha->primeiro == NULL){
    No *n_no = (No*) malloc(sizeof(No));
    n_no -> aluno = aluno;
    n_no->proximo = NULL;
    No **aux = &(pilha->primeiro);
    *aux = n_no;
    return 1;
  }
  
  No *no_aux = pilha->primeiro;
  No *no_aux_anterior = no_aux;
  while(no_aux != NULL){
    alu_acessa(no_aux->aluno, &matricula, nome, curso);
    if (matricula_base == matricula){
      return 0;
    }
    no_aux_anterior = no_aux;
    no_aux = no_aux->proximo;
  }
  No *n_no = (No*) malloc(sizeof(No));
  n_no -> aluno = aluno;
  n_no->proximo = NULL;
  
  No **aux = &(no_aux_anterior->proximo);
  *aux = n_no;
  return 1;
}

/* Remove um aluno na pilha. Retorna o aluno ou NULL caso a pilha esteja vazia ou
 * seja NULL */
Aluno *pilha_retira(Pilha *pilha) {
  if(pilha == NULL){
    return NULL;
  }
  Aluno * aluno_aux = pilha->primeiro->aluno;
  No ** aux = &(pilha->primeiro);
  *aux = pilha->primeiro->proximo;
  return aluno_aux;
}

/* Recupera o primeiro aluno da pilha. Retorna o aluno ou NULL caso a pilha esteja
 * vazia ou seja NULL */
Aluno *pilha_primeiro(Pilha *pilha) {
  if (pilha == NULL || pilha->primeiro == 0) {
    return NULL;
  }
  Aluno * aluno_aux = pilha->primeiro->aluno;
  return aluno_aux;
}

/* Busca aluno pelo número de matricula. Retorna o aluno se este estiver na
 * lista e NULL caso contrário, isto é, (i) pilha vazia; (ii) não exista aluno
 * com a matricula fornecida; ou (iii) a pilha seja NULL */
Aluno *pilha_busca(Pilha *pilha, int matricula) {
  if (pilha == NULL || pilha->primeiro == 0) {
    return NULL;
  }
  
  No *n_aux = pilha->primeiro;
  int matricula_comparada;
  char nome[50];
  char curso[30];
  
  do{
    alu_acessa(n_aux->aluno, &matricula_comparada, nome,curso);
    
    if(matricula_comparada == matricula){
      return n_aux->aluno;
    }
    
    n_aux = n_aux->proximo;
    
  }while(n_aux != NULL);
  
  return NULL;
}

/* Verifica se a pilha está vazia. Retorna 1 se a pilha estiver vazia, 0 caso não
 * esteja vazia e -1 se a pilha for NULL
 */
int pilha_vazia(Pilha *pilha) {
  if(pilha->primeiro == 0){
    return 1;
  }
  if(pilha == NULL){
    return -1;
  }
  return 0;
}

/* Computa a quantidade de alunos alunos na pilha. Retorna a quantidade de alunos
 * ou -1, caso a pilha for NULL.
 */
int pilha_quantidade(Pilha *pilha) {
  if (pilha == NULL) {
    return -1;
  }
  No * no_aux = pilha->primeiro;
  No *no_aux_anterior = no_aux;
  int total = 0;
  while(no_aux != NULL){
    total ++;
    no_aux_anterior = no_aux;
    no_aux = no_aux->proximo;
  }
  return total;
}